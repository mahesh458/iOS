//
//  main.m
//  PAStepper
//
//  Created by Miroslav Perovic on 12/1/12.
//  Copyright (c) 2012 Pure Agency. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
