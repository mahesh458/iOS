//
//  ViewController.h
//  PAStepper
//
//  Created by Miroslav Perovic on 12/1/12.
//  Copyright (c) 2012 Pure Agency. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PAStepper.h"

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet PAStepper *paStepper;

@end
