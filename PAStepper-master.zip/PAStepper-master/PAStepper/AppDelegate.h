//
//  AppDelegate.h
//  PAStepper
//
//  Created by Miroslav Perovic on 12/1/12.
//  Copyright (c) 2012 Pure Agency. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
