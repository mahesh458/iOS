//
//  ViewController.m
//  Strip
//
//  Created by John Charlin on 12/21/16.
//  Copyright © 2016 r. All rights reserved.
//

#import "ViewController.h"
#import <Stripe.h>

@interface ViewController ()
{
    IBOutlet UIButton *buyButton;
   STPPaymentCardTextField *string_textfiled;
    
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
     STPPaymentCardTextField *paymentField = [[STPPaymentCardTextField alloc] initWithFrame:CGRectMake(10, 10, 300, 44)];
    paymentField.delegate = self;
    [self.view addSubview:paymentField];
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)paymentCardTextFieldDidChange:(STPPaymentCardTextField *)textField {
    NSLog(@"Card number: %@ Exp Month: %@ Exp Year: %@", textField.cardParams.number, @(textField.cardParams.expMonth), @(textField.cardParams.expYear));
    buyButton.enabled = textField.isValid;
    string_textfiled =textField;
 
}

-(IBAction)selectshipping:(id)sender

{
//    PKPaymentRequest *paymentRequest = [Stripe paymentRequestWithMerchantIdentifier:@"com.merchant.your_application"];
//    paymentRequest.paymentSummaryItems = @[
//                                           [PKPaymentSummaryItem summaryItemWithLabel:@"Fancy Hat" amount:[NSDecimalNumber decimalNumberWithString:@"50.00"]],
//                                           // the final line should represent your company; it'll be prepended with the word "Pay" (i.e. "Pay iHats, Inc $50")
//                                           [PKPaymentSummaryItem summaryItemWithLabel:@"iHats, Inc" amount:[NSDecimalNumber decimalNumberWithString:@"50.00"]],
//                                           ];
    
STPCardParams *cardParams = [[STPCardParams alloc] init];
    cardParams.number=string_textfiled.cardParams.number;
    cardParams.expMonth = string_textfiled.cardParams.expMonth;
cardParams.expYear = string_textfiled.cardParams.expYear;
cardParams.cvc = string_textfiled.cardParams.cvc;
    
    if (string_textfiled.isValid) {
        [[STPAPIClient sharedClient] createTokenWithCard:cardParams completion:^(STPToken *token, NSError *error) {
            if (error) {
                // show the error, maybe by presenting an alert to the user
            } else {
                NSLog(@"token %@",token);
            }
        }];

    }
    


//    STPShippingAddressViewController *shippingViewController = [STPShippingAddressViewController new];
//    shippingViewController.delegate = self;
//    // STPShippingAddressViewController must be shown inside a UINavigationController.
//    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:shippingViewController];
//    [self presentViewController:navigationController animated:YES completion:nil];
}
- (void)shippingAddressViewControllerDidCancel:(STPShippingAddressViewController *)addressViewController {
    [addressViewController dismissWithCompletion:nil];
}

- (void)shippingAddressViewController:(STPShippingAddressViewController *)addressViewController didEnterAddress:(STPAddress *)address completion:(STPShippingMethodsCompletionBlock)completion {
    PKShippingMethod *upsGround = [PKShippingMethod new];
    upsGround.amount = [NSDecimalNumber decimalNumberWithString:@"0"];
    upsGround.label = @"UPS Ground";
    upsGround.detail = @"Arrives in 3-5 days";
    upsGround.identifier = @"ups_ground";
    PKShippingMethod *fedEx = [PKShippingMethod new];
    fedEx.amount = [NSDecimalNumber decimalNumberWithString:@"5.99"];
    fedEx.label = @"FedEx";
    fedEx.detail = @"Arrives tomorrow";
    fedEx.identifier = @"fedex";
    if ([address.country isEqualToString:@"US"]) {
        completion(STPShippingStatusValid, nil, @[upsGround, fedEx], upsGround);
    }
    else {
        completion(STPShippingStatusInvalid, nil, nil, nil);
    }
}
- (void)addCardViewControllerDidCancel:(STPAddCardViewController *)addCardViewController {
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)submitTokenToBackend:(STPToken *)token: (NSError*) error{
    
    
}
- (void)addCardViewController:(STPAddCardViewController *)addCardViewController
               didCreateToken:(STPToken *)token
                   completion:(STPErrorBlock)completion {
    
 
    
    }


    - (void)shippingAddressViewController:(STPShippingAddressViewController *)addressViewController didFinishWithAddress:(STPAddress *)address shippingMethod:(PKShippingMethod *)method {
    // Dismiss the view controller after updating your app with the user's shipping info
    [addressViewController dismissWithCompletion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
