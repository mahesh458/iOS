//
//  NIDropDown.h
//  NIDropDown
//
//  Created by Bijesh N on 12/28/12.
//  Copyright (c) 2012 Nitor Infotech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QuartzCore/QuartzCore.h"

@class NIDropDown;

@protocol NIDropDownDelegate
- (void) niDropDownDelegateMethod: (NIDropDown *) sender;
@end

@interface NIDropDown : UIView <UITableViewDelegate, UITableViewDataSource>
{
    NSString         * strAnimationDirection;
   // NSMutableArray  * arrayList;
    
    GlobalVariables  * globalVariable;
}

@property (nonatomic, retain) id <NIDropDownDelegate> delegate;
@property (nonatomic, retain) NSString *strAnimationDirection;
@property (nonatomic,retain) UIViewController *parentView;

#pragma mark -Method Prototype
-(void)hideDropDown:(UITextField *)b;
- (id)showDropDown:(UITextField *)b height:(CGFloat *)height array:(NSMutableArray *)arr direction:(NSString *)direction descriptionField:(UITextView *)desciptionText;

//- (id)showDropDown:(UIButton *)b height:(CGFloat *)height array:(NSMutableArray *)arr direction:(NSString *)direction descriptionField:(UITextView *)desciptionText;
#pragma mark -Method Prototype

@end
