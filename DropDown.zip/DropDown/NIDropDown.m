//
//  NIDropDown.m
//  NIDropDown
//
//  Created by Bijesh N on 12/28/12.
//  Copyright (c) 2012 Nitor Infotech. All rights reserved.
//

#import "NIDropDown.h"


@interface NIDropDown ()
@property(nonatomic, strong) UITableView *table;
@property(nonatomic, strong) UITextField *btnSender;
@property(nonatomic, strong) UITextView *descriptionTextField;
@property(nonatomic, retain) NSMutableArray *list;
@end

@implementation NIDropDown
@synthesize table;
@synthesize btnSender;
@synthesize list,parentView,descriptionTextField;


@synthesize delegate;
@synthesize strAnimationDirection;

- (id)showDropDown:(UITextField *)b height:(CGFloat *)height array:(NSMutableArray *)arr direction:(NSString *)direction descriptionField:(UITextView *)desciptionText {
    btnSender = b;
    descriptionTextField = desciptionText;
    
    globalVariable=[GlobalVariables sharedInstanceMethod];
  
    strAnimationDirection = direction;
    self.table= (UITableView *)[super init];
    if (self) {
        // Initialization code
        CGRect btn = b.frame;
        self.list = [NSMutableArray arrayWithArray:arr];
        if ([direction isEqualToString:@"up"]) {
            self.frame = CGRectMake(btn.origin.x, btn.origin.y, btn.size.width, 0);
        }else if ([direction isEqualToString:@"down"]) {
            self.frame = CGRectMake(btn.origin.x, btn.origin.y+btn.size.height, btn.size.width, 0);
        }
        
        self.layer.masksToBounds = NO;
        
        table = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, btn.size.width, 0)];
        table.delegate = self;
        table.dataSource = self;
       // table.backgroundColor = [UIColor lightGrayColor];
       // table.backgroundColor = [UIColor clearColor];
       // table.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
      //  table.layer.borderColor=[UIColor blackColor].CGColor;
      //  table.layer.borderWidth=1.0f;
       // table.separatorColor = [UIColor blackColor];
        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        if ([direction isEqualToString:@"up"]) {
            self.frame = CGRectMake(btn.origin.x, btn.origin.y-*height, btn.size.width, *height);
        } else if([direction isEqualToString:@"down"]) {
            self.frame = CGRectMake(btn.origin.x, btn.origin.y+btn.size.height, btn.size.width, *height);
        }
        table.frame = CGRectMake(0, 0, btn.size.width, *height);
        [UIView commitAnimations];
        [b.superview addSubview:self];
        [self addSubview:table];
        table.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    }
    return self;
}

-(void)hideDropDown:(UITextField *)b {
    CGRect btn = b.frame;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if ([strAnimationDirection isEqualToString:@"up"]) {
        self.frame = CGRectMake(btn.origin.x, btn.origin.y, btn.size.width, 0);
    }else if ([strAnimationDirection isEqualToString:@"down"]) {
        self.frame = CGRectMake(btn.origin.x, btn.origin.y+btn.size.height, btn.size.width, 0);
    }
    table.frame = CGRectMake(0,0, btn.size.width, 0);
    [UIView commitAnimations];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 35;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [globalVariable.arrmForumCategoryName count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    [cell.textLabel setText:[NSString stringWithFormat:@"%@",[globalVariable.arrmForumCategoryName objectAtIndex:indexPath.row]]];
    cell.textLabel.textColor = [UIColor blackColor];
    
    cell.textLabel.font = [UIFont systemFontOfSize:15];
    [cell.textLabel setTextAlignment:NSTextAlignmentLeft];
    cell.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
    cell.textLabel.numberOfLines = 0;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];

   // [btnSender setTitle:[globalVariable.arrmForumCategoryName objectAtIndex:0] forState:UIControlStateNormal];
    
   // [btnSender setTitle:cell.textLabel.text forState:UIControlStateNormal];
    
    [btnSender setText:cell.textLabel.text];
    
    [btnSender setTag:0];
    
//    btnSender.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
//    btnSender.titleLabel.numberOfLines = 0;
    
   // [btnSender.titleLabel setTextAlignment:NSTextAlignmentLeft];
    //[btnSender sizeThatFits:btnSender.titleLabel.frame.size];
    //[btnSender setTitleEdgeInsets:UIEdgeInsetsMake(10.0, 40.0, 10.0, 45.0)];
    
    globalVariable.strForumCategoryId = [globalVariable.arrmForumCategoryId objectAtIndex:indexPath.row];
    
    [self hideDropDown:btnSender];
    
    [self myDelegate];
}

/*
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    
        [cell setBackgroundColor:[UIColor clearColor]];
        
        CAGradientLayer *grad = [CAGradientLayer layer];
        grad.frame = cell.bounds;
        grad.colors = [NSArray arrayWithObjects:(id)[[UIColor whiteColor] CGColor], (id)[[UIColor colorWithRed:47.0f/255.0f green:110.0f/255.0f blue:175.0f/255.0f alpha:1.0f] CGColor], nil];
        
        [cell setBackgroundView:[[UIView alloc] init]];
        [cell.backgroundView.layer insertSublayer:grad atIndex:0];
}
 */

- (void) myDelegate {
    [self.delegate niDropDownDelegateMethod:self];
}
@end
