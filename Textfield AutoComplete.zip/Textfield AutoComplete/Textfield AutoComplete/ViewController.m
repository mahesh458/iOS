//
//  ViewController.m
//  Textfield AutoComplete
//
//  Created by ndot on 18/07/15.
//  Copyright (c) 2015 Ktr. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *autoCompleteField;
@property (strong, nonatomic) IBOutlet UITableView *autoCompleteTableView;
@property (nonatomic, retain) NSMutableArray *autoCompleteArray;
@property (nonatomic, retain) NSArray *autoCompleteFilterArray;
- (IBAction)GoBtnAction:(id)sender;

@end

@implementation ViewController
@synthesize autoCompleteArray;
@synthesize autoCompleteField,autoCompleteTableView;
@synthesize autoCompleteFilterArray;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    autoCompleteArray = [[NSMutableArray alloc] initWithArray:[[NSUserDefaults standardUserDefaults] arrayForKey:@"autocomplete"]];
    
    autoCompleteTableView.hidden =TRUE;
    
    autoCompleteTableView.tableFooterView = [UIView new];
    
    [[autoCompleteTableView layer] setMasksToBounds:NO];
    [[autoCompleteTableView layer] setShadowColor:[UIColor blackColor].CGColor];
    [[autoCompleteTableView layer] setShadowOffset:CGSizeMake(0.0f, 5.0f)];
    [[autoCompleteTableView layer] setShadowOpacity:0.3f];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITextField Delegate
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{

    NSLog(@"Range:%@",NSStringFromRange(range));
    NSLog(@"%@",textField.text);
    
    NSString *passcode = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    NSLog(@"%@",passcode);
  
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:
                              @"SELF CONTAINS %@",passcode];
   // NSPredicate *predicate = [NSPredicate predicateWithFormat:@"ANY SELF = %@", passcode];
    
    autoCompleteFilterArray = [autoCompleteArray filteredArrayUsingPredicate:predicate];
    NSLog(@"%@", autoCompleteFilterArray);
    
    if ([autoCompleteFilterArray count]==0) {
        autoCompleteTableView.hidden = TRUE;
    }else{
        autoCompleteTableView.hidden = FALSE;
    }
    
    [autoCompleteTableView reloadData];
    
    
    return TRUE;
    
}


#pragma mark - UIButton Action
- (IBAction)GoBtnAction:(id)sender {
    
    if (autoCompleteField.text.length != 0) {
        [autoCompleteArray addObject:autoCompleteField.text];
        
        NSLog(@"AutoComplet Arr : %@",autoCompleteArray);
        
        [[NSUserDefaults standardUserDefaults] setObject:autoCompleteArray forKey:@"autocomplete"];
        
        autoCompleteField.text = @"";

    }
}


#pragma mark - UITableView Delegate


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [autoCompleteFilterArray count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *Cell = [tableView dequeueReusableHeaderFooterViewWithIdentifier:nil];
    if (Cell ==nil) {
        Cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    }
    
    Cell.textLabel.text = [NSString stringWithFormat:@"%@",[autoCompleteFilterArray objectAtIndex:indexPath.row]];
    Cell.contentView.backgroundColor = [UIColor whiteColor];
    Cell.backgroundColor = [UIColor clearColor];
    
    UIView* separatorLineView = [[UIView alloc] initWithFrame:CGRectMake(0, 40, 320, 20)];/// change size as you need.
    separatorLineView.backgroundColor = [UIColor clearColor];// you can also put image here
    [Cell.contentView addSubview:separatorLineView];
    
   
    
    return Cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *Cell = [tableView cellForRowAtIndexPath:indexPath];
    autoCompleteField.text =Cell.textLabel.text;
}

@end
