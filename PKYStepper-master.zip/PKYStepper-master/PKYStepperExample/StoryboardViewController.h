//
//  StoryboardViewController.h
//  PKYStepper
//
//  Created by Okada Yohei on 1/25/15.
//  Copyright (c) 2015 yohei okada. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StoryboardViewController : UIViewController

@end
