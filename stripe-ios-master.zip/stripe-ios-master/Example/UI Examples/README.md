# UI Examples

This example app lets you try out the pre-built UI components we provide. 
You can run it without any initial setup, and it's a great place to start if 
you're evaluating whether you want to use our UI components in your app.

If you'd like to use our pre-built UI components, you can refer to our 
Standard Integration app for an example of how to use `STPPaymentContext` 
to present our UI components and drive your app's payment flow.
