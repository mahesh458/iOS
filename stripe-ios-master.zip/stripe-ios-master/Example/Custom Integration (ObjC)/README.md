# Custom Integration (ObjC)

This example app demonstrates how to to use `STPAPIClient` to accept various payment methods. These integrations may be a useful reference if you're building your own payment UI, and not using `STPPaymentContext`. 

For a detailed guide on the various subcomponents of the SDK, see https://stripe.com/docs/mobile/ios/custom

For more details on using Sources with the iOS SDK, see https://stripe.com/docs/mobile/ios/sources
