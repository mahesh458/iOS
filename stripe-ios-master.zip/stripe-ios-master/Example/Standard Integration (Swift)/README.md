# Standard Integration (Swift)

This example app demonstrates how to build a payment flow using our pre-built UI components (`STPPaymentContext`).

For a detailed guide, see https://stripe.com/docs/mobile/ios/standard
