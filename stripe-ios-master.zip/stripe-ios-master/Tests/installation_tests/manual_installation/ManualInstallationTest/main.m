//
//  main.m
//  ManualInstallationTest
//
//  Created by Jack Flintermann on 5/15/15.
//  Copyright (c) 2015 stripe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
